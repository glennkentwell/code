'''
Just a script to generate an address file for
an emulab install.
'''
for i in xrange(0, 50):
	print "node-%d 50000" % i
